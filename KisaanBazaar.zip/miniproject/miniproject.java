//Name:Gauri Bankar
//UCE023411
//Problem Staement:
//Design mobile phone contact list which stores name and contact number
// in ascending order. Develop a code to search a particular contact 
//details of specified name,insert new contact and delete particular 
//contact from list.

import java.util.*;

//student class
class Student {
    int id;
    String name;

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // By default, toString() returns gibberish,
    // but here we override it to return a more meaningful representation.
    @Override
    public String toString() {
        return id + " (" + name + ")";
    }
}

class Admin extends Student {
    private String username;
    private String password;

    public Admin(int id, String name, String username, String password) {
        super(id, name);  // Call the parent class (Student) constructor
        this.username = username;
        this.password = password;
    }

    public boolean authenticate(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }


    @Override
    public String toString() {
        return super.toString() + " (Admin)";
    }
}

 class CampusConnect {
    // Graph (Adjacency list) for coonnections
    private Map<Integer, Set<Integer>> graph;  
    // Stores student details with stdent id as key 
    private Map<Integer, Student> students;  
    //instance of admin class used for authentication below  
    private Admin admin;

    //constructor
    public CampusConnect(String adminUsername, String adminPassword) {
        graph = new HashMap<>(); 
        students = new HashMap<>(); 
        this.admin = new Admin(0, "Administrator", adminUsername, adminPassword);

        // Hardcode students and their connections
        hardcodeData();
    }

    // Hardcode students and their connections
    private void hardcodeData() {
        // Adding students
        Student student1 = new Student(1, "Ananya");
        Student student2 = new Student(2, "Bunty");
        Student student3 = new Student(3, "Disha");
        Student student4 = new Student(4, "Priya");
        Student student5 = new Student(5, "Harsh");
        Student student6 = new Student(6, "Kartik");

        addStudent(student1);
        addStudent(student2);
        addStudent(student3);
        addStudent(student4);
        addStudent(student5);
        addStudent(student6);

        // Adding connections (variety of connections)
        addConnection(1, 2); 
        addConnection(1, 3); 
        addConnection(2, 4); 
        addConnection(2, 5); 
        addConnection(3, 5); 
        addConnection(4, 6); 
        addConnection(5, 6); 

       
    }

    // Add a new student
    public void addStudent(Student student) {
        if (student.id < 0) {
            System.out.println("Student ID cannot be negative.");
            return;
        }

        if (!students.containsKey(student.id)) {
            students.put(student.id, student);
            graph.put(student.id, new HashSet<>());
        } else {
            System.out.println("Student with ID " + student.id + " already exists.");
        }
    }

    // Connecting two students
    public void addConnection(int id1, int id2) {
        if (!students.containsKey(id1) || !students.containsKey(id2)) {
            System.out.println("One or both students not found.");
            return;
        }

        if (id1 == id2) {
            System.out.println("Cannot connect a student to themselves.");
            return;
        }

        graph.get(id1).add(id2);
        graph.get(id2).add(id1);
    }

    // Removing a student
    public void removeStudent(int id) {
        if (students.containsKey(id)) {
            //remove from graph
            graph.remove(id);
            //remove its connections
            for (Set<Integer> connections : graph.values()) {
                connections.remove(id);
            }
            //remove from hashmap
            students.remove(id);
            System.out.println("Student ID " + id + " removed.");
        } else {
            System.out.println("Student not found.");
        }
    }

    // View all student connections
    public void viewAllConnections() {
        //entry refers to the stud id refered currently
        for (Map.Entry<Integer, Set<Integer>> entry : graph.entrySet()) {
            System.out.println("Student " + entry.getKey() + " (" + students.get(entry.getKey()).name + ") -> " + entry.getValue());
        }
    }

    // View isolated students
    public void viewIsolatedStudents() {
        for (Map.Entry<Integer, Set<Integer>> entry : graph.entrySet()) {
            if (entry.getValue().isEmpty()) {
                System.out.println("Isolated Student: " + entry.getKey() + " (" + students.get(entry.getKey()).name + ")");
            }
        }
    }

    // View mutual connections between two students
    public void viewMutualConnections(int id1, int id2) {
        if (!students.containsKey(id1) || !students.containsKey(id2)) {
            System.out.println("One or both students not found.");
            return;
        }

        Set<Integer> mutualConnections = new HashSet<>(graph.get(id1));
        mutualConnections.retainAll(graph.get(id2));

        if (mutualConnections.isEmpty()) {
            System.out.println("No mutual connections between Student " + id1 + " and Student " + id2 + ".");
        } else {
            System.out.println("Mutual connections between Student " + id1 + " and Student " + id2 + ": " + mutualConnections);
        }
    }

    // Admin authentication
    int adminAccess(String username, String password) {
        //check if username n password are same as its stored value 
        if (admin.authenticate(username, password)) {
            System.out.println("Admin access granted.");
            return 1;
        } else {
            System.out.println("Invalid admin credentials.");
        }
        return 0;
    }
}

public class miniproject {
    public static void main(String[] args) {
        CampusConnect campus = new CampusConnect("admin", "1234");
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n--- CampusConnect ---");
        System.out.println("Who are you?");
        System.out.println("1.Admin");
        System.out.println("2.Student");
        int ch=scanner.nextInt();
        switch(ch)
        {
            case 1:

        System.out.print("Enter Admin Username: ");
        String adminUsername = scanner.next();
        System.out.print("Enter Admin Password: ");
        String adminPassword = scanner.next();
        int access=campus.adminAccess(adminUsername, adminPassword);
        if (access==1)
        {
        while (true) {
           System.out.println("\n--- CampusConnect Menu ---"); 
            System.out.println("1. Add Student");
            System.out.println("2. Add Connection");
            System.out.println("3. Remove Student");
            System.out.println("4. View All Connections");
            System.out.println("5. View Isolated Students");
            System.out.println("6. View Mutual Connections");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
            
                case 1:  // Add Student
                    System.out.print("Enter Student ID: ");
                    int studentId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Student Name: ");
                    String studentName = scanner.nextLine();
                    campus.addStudent(new Student(studentId, studentName));
                    break;

                case 2:  // Add Connection
                    System.out.print("Enter First Student ID: ");
                    int id1 = scanner.nextInt();
                    System.out.print("Enter Second Student ID: ");
                    int id2 = scanner.nextInt();
                    campus.addConnection(id1, id2);
                    break;

                case 3:  // Remove Student
                    System.out.print("Enter Student ID to Remove: ");
                    int removeId = scanner.nextInt();
                    campus.removeStudent(removeId);
                    break;

                case 4:  // View All Connections
                    System.out.println("All Connections:");
                    campus.viewAllConnections();
                    break;

                case 5:  // View Isolated Students
                    System.out.println("Isolated Students:");
                    campus.viewIsolatedStudents();
                    break;

                case 6:  // View Mutual Connections
                    System.out.print("Enter First Student ID: ");
                    int mutualId1 = scanner.nextInt();
                    System.out.print("Enter Second Student ID: ");
                    int mutualId2 = scanner.nextInt();
                    campus.viewMutualConnections(mutualId1, mutualId2);
                    break;

                case 7:  // Exit
                    System.out.println("Exiting CampusConnect. Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
    break;

    case 2:

        break;
    }
    }
}
